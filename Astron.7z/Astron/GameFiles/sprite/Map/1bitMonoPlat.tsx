<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="1bitMonoPlat" tilewidth="16" tileheight="16" tilecount="400" columns="20">
 <image source="1bitplatformerpack/Tilemap/monochrome_tilemap_packed.png" width="320" height="320"/>
</tileset>
