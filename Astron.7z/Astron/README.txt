GameName:
Astron

GameDescription:

Astron is a BountyHunter.
After a nuclear war has devasted the surface of the planet, the remaining survivors live a life of constant fear, fighting, and survival.
In order to earn money and survive the wasteland, Atron has to fight the remains of the victims, coming back to life due to the radiations.

In this game the player has to finish the game without dying. Astron can shoot, jump, double jump and wall jump. 
You can die if you touch an enemy or if you touch the spikes.
In order to increase your score, you have to collect coins and kill enemies. You can also try to speedrun the game with the integrated timer.
Try to win without diying :)


GameControls:
[D] = Strafe Right
[Q] = Strafe Left
[Space] = Jump
[ECHAP] = Pause Game
[SUPPR] = Show Hitboxes
[RIGHT ARROW] =  Shoot Right
[LEFT ARROW] = Shoot Left
[RIGHT ARROW]+[UP ARROW] = Shoot Up Right
[LEFT ARROW]+[UP ARROW] = Shoot Up Left


sources:

JS Canneva:
https://developer.mozilla.org/fr/docs/Web/HTML/Element/canvas
https://www.javatpoint.com/how-to-make-a-javascript-game
https://www.w3schools.com/graphics/game_intro.asp


Js request animation frame:
https://developer.mozilla.org/en-US/docs/Web/API/window/requestAnimationFrame

Js module, import,export:
https://www.pierre-giraud.com/javascript-apprendre-coder-cours/module-import-export/
https://developer.mozilla.org/fr/docs/Web/JavaScript/Guide/Modules
https://javascript.info/import-export

js audio:
https://stackoverflow.com/questions/3273552/html5-audio-looping

js image:
https://www.w3schools.com/tags/canvas_drawimage.asp

Keyboard js:
https://www.w3schools.com/graphics/game_controllers.asp
http://javascriptkeycode.com/

Math js:
https://mathjs.org/

js splice:
https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Array/splice

js objet:
https://www.w3schools.com/js/js_objects.asp
https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Object

Game maker:
https://www.mapeditor.org
https://www.kenney.nl/assets/bit-platformer-pack
https://freesound.org
http://soundimage.org
https://99sounds.org
https://opengameart.org